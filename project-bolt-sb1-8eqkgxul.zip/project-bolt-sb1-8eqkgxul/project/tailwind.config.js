/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{html,js,svelte,ts}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#e6f0fd',
          100: '#cce0fb',
          200: '#99c2f7',
          300: '#66a3f3',
          400: '#3385ef',
          500: '#0071e3', // Main primary
          600: '#005ab6',
          700: '#004388',
          800: '#002d5b',
          900: '#00162d',
        },
        secondary: {
          50: '#ebfcf0',
          100: '#d6f9e1',
          200: '#aef3c3',
          300: '#85eda5',
          400: '#5de787',
          500: '#34c759', // Main secondary
          600: '#29a047',
          700: '#1f7835',
          800: '#145023',
          900: '#0a2812',
        },
        accent: {
          50: '#fff8e6',
          100: '#fff0cc',
          200: '#ffe199',
          300: '#ffd266',
          400: '#ffc333',
          500: '#ff9500', // Main accent
          600: '#cc7700',
          700: '#995900',
          800: '#663b00',
          900: '#331e00',
        },
        success: '#34c759',
        warning: '#ff9500',
        error: '#ff3b30',
        neutral: {
          50: '#f9fafb',
          100: '#f3f4f6',
          200: '#e5e7eb',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
          600: '#4b5563',
          700: '#374151',
          800: '#1f2937',
          900: '#111827',
        }
      },
      spacing: {
        '1': '8px',
        '2': '16px',
        '3': '24px',
        '4': '32px',
        '5': '40px',
        '6': '48px',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-in-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      }
    },
  },
  plugins: [],
}