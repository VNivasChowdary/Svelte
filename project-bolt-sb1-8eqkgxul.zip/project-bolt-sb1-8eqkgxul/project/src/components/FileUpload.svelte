<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  import { parseTextFile } from '../services/api';

  const dispatch = createEventDispatcher();
  
  let fileInput: HTMLInputElement;
  let isDragging = false;
  let fileName = '';
  let error: string | null = null;
  
  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    
    const file = files[0];
    
    if (file.type !== 'text/plain') {
      error = 'Please upload a text (.txt) file';
      fileName = '';
      return;
    }
    
    error = null;
    fileName = file.name;
    
    try {
      const domains = await parseTextFile(file);
      dispatch('fileProcessed', { domains });
    } catch (err) {
      console.error('Error processing file:', err);
      error = 'Failed to process file';
    }
  }
  
  function handleDragOver(event: DragEvent) {
    event.preventDefault();
    isDragging = true;
  }
  
  function handleDragLeave() {
    isDragging = false;
  }
  
  function handleDrop(event: DragEvent) {
    event.preventDefault();
    isDragging = false;
    handleFiles(event.dataTransfer?.files || null);
  }
  
  function triggerFileInput() {
    fileInput.click();
  }
</script>

<div 
  class="w-full border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors duration-200 animate-fade-in"
  class:border-primary-400={isDragging}
  class:bg-primary-50={isDragging}
  class:border-neutral-300={!isDragging}
  on:dragover={handleDragOver}
  on:dragleave={handleDragLeave}
  on:drop={handleDrop}
  on:click={triggerFileInput}
>
  <input 
    type="file" 
    accept=".txt"
    class="hidden" 
    bind:this={fileInput}
    on:change={(e) => handleFiles(e.target.files)}
  />
  
  <svg xmlns="http://www.w3.org/2000/svg" class="mx-auto h-12 w-12 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
  </svg>
  
  {#if fileName}
    <p class="mt-2 text-sm text-neutral-600">Selected: <span class="font-medium">{fileName}</span></p>
  {:else}
    <p class="mt-2 text-sm text-neutral-600">
      Drag and drop a text file here, or click to select
    </p>
    <p class="text-xs text-neutral-500 mt-1">Only .txt files are supported</p>
  {/if}
  
  {#if error}
    <p class="mt-2 text-sm text-error">{error}</p>
  {/if}
</div>