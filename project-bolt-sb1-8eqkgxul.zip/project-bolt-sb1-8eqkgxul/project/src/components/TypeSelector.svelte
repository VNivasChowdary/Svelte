<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  import type { SelectionType } from '../types';
  
  const dispatch = createEventDispatcher();
  
  export let selected: SelectionType = 'domain';
  
  const options: { value: SelectionType; label: string }[] = [
    { value: 'scope', label: 'Scope' },
    { value: 'subs', label: 'Subs' },
    { value: 'domain', label: 'Domain' }
  ];
  
  function handleChange(value: SelectionType) {
    selected = value;
    dispatch('select', { type: value });
  }
</script>

<div class="flex flex-col space-y-3 animate-fade-in">
  <h3 class="text-lg font-medium text-neutral-800">Select Type</h3>
  
  <div class="flex flex-col space-y-2">
    {#each options as option}
      <label 
        class="flex items-center p-3 rounded-md border transition-all duration-200 cursor-pointer"
        class:border-primary-500={selected === option.value}
        class:bg-primary-50={selected === option.value}
        class:border-neutral-200={selected !== option.value}
        class:hover:border-primary-300={selected !== option.value}
      >
        <input 
          type="radio" 
          name="type" 
          value={option.value} 
          checked={selected === option.value}
          class="hidden"
          on:change={() => handleChange(option.value)}
        />
        <div class="w-5 h-5 rounded-full border flex items-center justify-center mr-3"
          class:border-primary-500={selected === option.value}
          class:border-neutral-400={selected !== option.value}
        >
          {#if selected === option.value}
            <div class="w-3 h-3 rounded-full bg-primary-500"></div>
          {/if}
        </div>
        <span class="text-neutral-800">{option.label}</span>
      </label>
    {/each}
  </div>
</div>