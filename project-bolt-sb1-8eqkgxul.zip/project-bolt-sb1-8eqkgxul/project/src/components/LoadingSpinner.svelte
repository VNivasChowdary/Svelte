<script lang="ts">
  export let size = "24px";
  export let color = "#0071e3";
</script>

<svg 
  width={size} 
  height={size} 
  viewBox="0 0 24 24" 
  xmlns="http://www.w3.org/2000/svg"
  class="animate-spin">
  <circle
    cx="12"
    cy="12"
    r="10"
    stroke-width="4"
    stroke="currentColor"
    stroke-opacity="0.25"
    fill="none"
    class="text-neutral-200"
  />
  <path
    d="M12 2a10 10 0 0 1 10 10"
    stroke="currentColor"
    stroke-width="4"
    stroke-linecap="round"
    fill="none"
    class="text-primary-500"
    style="color: {color};"
  />
</svg>