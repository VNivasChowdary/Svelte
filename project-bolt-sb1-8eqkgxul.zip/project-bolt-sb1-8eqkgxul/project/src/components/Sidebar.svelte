<script lang="ts">
  import { onMount } from 'svelte';
  import { push } from 'svelte-spa-router';
  import { getAvailableReports } from '../services/api';
  import type { Report } from '../services/api';
  import LoadingSpinner from './LoadingSpinner.svelte';

  let reports: Report[] = [];
  let isLoading = true;
  let error: string | null = null;

  onMount(async () => {
    try {
      isLoading = true;
      reports = await getAvailableReports();
    } catch (err) {
      error = err instanceof Error ? err.message : "Failed to load reports";
      console.error(err);
    } finally {
      isLoading = false;
    }
  });

  function navigateToReport(reportId: string) {
    push(`/report/${reportId}`);
  }
</script>

<aside class="h-full w-64 bg-white border-r border-neutral-200 flex flex-col">
  <div class="p-4 border-b border-neutral-200">
    <h2 class="text-xl font-semibold text-neutral-800">Recent Reports</h2>
  </div>
  
  <div class="flex-1 overflow-y-auto p-2">
    {#if isLoading}
      <div class="flex justify-center items-center h-20">
        <LoadingSpinner />
      </div>
    {:else if error}
      <div class="p-3 text-error text-center">
        {error}
        <button 
          class="block mx-auto mt-2 text-sm text-primary-500 hover:underline"
          on:click={() => window.location.reload()}>
          Retry
        </button>
      </div>
    {:else if reports.length === 0}
      <div class="p-3 text-neutral-500 text-center">
        No reports available
      </div>
    {:else}
      <ul class="space-y-1">
        {#each reports as report}
          <li>
            <button 
              class="w-full text-left p-2 rounded-md hover:bg-neutral-100 transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-primary-500"
              on:click={() => navigateToReport(report.id)}>
              <span class="block font-medium text-neutral-800">{report.name}</span>
              {#if report.description}
                <span class="block text-sm text-neutral-500">{report.description}</span>
              {/if}
            </button>
          </li>
        {/each}
      </ul>
    {/if}
  </div>
</aside>
