<script lang="ts">
  import Router from 'svelte-spa-router'
  import { routes } from './routes'
  import Sidebar from './components/Sidebar.svelte'
</script>

<main class="flex h-screen w-screen overflow-hidden bg-neutral-50">
  <Sidebar />
  <div class="flex-1 overflow-y-auto p-4">
    <Router {routes} />
  </div>
</main>

<style>
  :global(html, body) {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>