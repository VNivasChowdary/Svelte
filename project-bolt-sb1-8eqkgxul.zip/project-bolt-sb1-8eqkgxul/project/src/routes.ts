import Home from './pages/Home.svelte'
import ReportDetail from './pages/ReportDetail.svelte'
import NotFound from './pages/NotFound.svelte'

export const routes = {
  '/': Home,
  '/report/:id': ReportDetail,
  '*': NotFound
}