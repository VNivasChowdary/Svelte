export interface ReportData {
  [key: string]: any;
}

export interface ReportRequest {
  domain: string[];
  type?: string;
}

export type SelectionType = 'scope' | 'subs' | 'domain';