<script>
  import { push } from 'svelte-spa-router';
</script>

<div class="flex flex-col items-center justify-center h-full text-center animate-fade-in">
  <h1 class="text-4xl font-bold text-neutral-800 mb-2">404</h1>
  <h2 class="text-2xl font-medium text-neutral-600 mb-6">Page Not Found</h2>
  <p class="text-neutral-500 mb-8">
    The page you are looking for doesn't exist or has been moved.
  </p>
  <button 
    class="btn btn-primary"
    on:click={() => push('/')}
  >
    Go to Home
  </button>
</div>