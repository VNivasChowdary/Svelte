<script lang="ts">
  import { onMount } from 'svelte';
  import { location } from 'svelte-spa-router';
  import { getReportData, convertToCSV } from '../services/api';
  import LoadingSpinner from '../components/LoadingSpinner.svelte';
  import type { ReportData, ReportRequest } from '../types';
  //@ts-ignore
  import * as XLSX from 'xlsx';


  let reportId: string = '';
let reportData: ReportData | null = null;
let isLoading = true;
let error: string | null = null;

$: {
  const match = /\/report\/([^/]+)/.exec($location);
  reportId = match ? match[1] : '';
}

onMount(async () => {
  try {
    // Set loading state before making the API call
    isLoading = true;
    
    // const requestDataString = sessionStorage.getItem('reportRequest');
    // if (!requestDataString) {
    //   error = 'No report request data found';
    //   return;
    // }
    
    // const requestData = JSON.parse(requestDataString) as ReportRequest;
    
    // Fetch data from the API
    reportData = await getReportData();
    console.log('Fetched report data:', reportData);

    // Reset error if data fetch was successful
    error = null;
  } catch (err) {
    console.error('Error fetching report data:', err);
    error = 'Failed to load report data';
    reportData = null;  // Ensure reportData is cleared on error
  } finally {
    isLoading = false;  // Reset loading state
  }
});

  
  function formatData(data: any): string {
    return JSON.stringify(data, null, 2);
  }


async function downloadExcel() {
  const reportData = await getReportData();
  if (!reportData) return;

  const workbook = XLSX.utils.book_new();

  for (const sectionName in reportData) {
    const sectionData = reportData[sectionName as keyof typeof reportData];

    if (!sectionData || sectionData.length === 0) continue;

    let worksheet;

    // If it's an array of objects (typical report data)
    if (Array.isArray(sectionData) && typeof sectionData[0] === 'object') {
      worksheet = XLSX.utils.json_to_sheet(sectionData);

      // Apply bold styling to header row
      const range = XLSX.utils.decode_range(worksheet['!ref']!); // Get range of the sheet
      for (let col = range.s.c; col <= range.e.c; col++) {
        const cell_address = { r: range.s.r, c: col }; // First row
        const cell_ref = XLSX.utils.encode_cell(cell_address);

        if (!worksheet[cell_ref]) continue;

        // Apply bold styling to the header row
        worksheet[cell_ref].s = {
          font: { bold: true },
        };
      }
    } else {
      // Handle case where data is not an array of objects
      const aoa = sectionData.map(item => [item]);
      worksheet = XLSX.utils.aoa_to_sheet(aoa);
    }

    // Add the worksheet to the workbook
    XLSX.utils.book_append_sheet(workbook, worksheet, sectionName.slice(0, 31));
  }

  // Generate and download the Excel file
  XLSX.writeFile(workbook, `report-${new Date().toISOString().split('T')[0]}.xlsx`);
}




</script>

<div class="animate-slide-in">
  <div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-semibold text-neutral-800">
      Report: {reportId}
    </h1>
    
    <div class="flex gap-2">
      {#if reportData}
        <button 
          class="btn bg-primary-100 text-primary-700 hover:bg-primary-200"
          on:click={downloadExcel}
        >
          Download CSV
        </button>
      {/if}
      <button 
        class="btn bg-neutral-200 hover:bg-neutral-300 text-neutral-800"
        on:click={() => window.history.back()}
      >
        Back
      </button>
    </div>
  </div>
  
  <div class="card">
    {#if isLoading}
      <div class="flex justify-center items-center h-40">
        <LoadingSpinner size="36px" />
      </div>
    {:else if error}
      <div class="p-4 bg-error-50 border border-error text-error rounded-md">
        <h3 class="font-medium mb-2">Error</h3>
        <p>{error}</p>
        <button 
          class="mt-3 text-primary-500 hover:underline"
          on:click={() => window.history.back()}>
          Return to home
        </button>
      </div>
      {:else if reportData && reportData[reportId]}
      <div class="overflow-auto">
        <div class="space-y-6">
          
          {#if reportId === 'dns_records'}
            <section>
              <h2 class="text-lg font-semibold mb-2">DNS Records</h2>
              <div class="overflow-x-auto">
                <table class="table-auto w-full text-sm border">
                  <thead>
                    <tr>
                      <th class="border px-2 py-1">Domain</th>
                      <th class="border px-2 py-1">A Records</th>
                      <th class="border px-2 py-1">CNAME Records</th>
                      <th class="border px-2 py-1">TXT Records</th>
                    </tr>
                  </thead>
                  <tbody>
                    {#each reportData.dns_records as rec}
                      <tr>
                        <td class="border px-2 py-1">{rec.Domain}</td>
                        <td class="border px-2 py-1">{rec["A Records"]}</td>
                        <td class="border px-2 py-1">{rec["CNAME Records"]}</td>
                        <td class="border px-2 py-1">{rec["TXT Records"]}</td>
                      </tr>
                    {/each}
                  </tbody>
                </table>
              </div>
            </section>
          
          {:else if reportId === 'ip_address'}
            <section>
              <h2 class="text-lg font-semibold mb-2">IP Addresses</h2>
              <ul class="list-disc pl-6">
                {#each reportData.ip_address as ip}
                  <li>{ip}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'domain_status'}
            <section>
              <h2 class="text-lg font-semibold mb-2">Domain Status</h2>
              <div class="overflow-x-auto">
                <table class="table-auto w-full text-sm border">
                  <thead>
                    <tr>
                      <th class="border px-2 py-1">Domain</th>
                      <th class="border px-2 py-1">Status Code</th>
                      <th class="border px-2 py-1">TLSv1.2</th>
                      <th class="border px-2 py-1">Valid Status</th>
                      <th class="border px-2 py-1">WAF</th>
                    </tr>
                  </thead>
                  <tbody>
                    {#each reportData.domain_status as d}
                      <tr>
                        <td class="border px-2 py-1">{d.Domain}</td>
                        <td class="border px-2 py-1">{d["Status Code"]}</td>
                        <td class="border px-2 py-1">{d["TLSv1.2"]}</td>
                        <td class="border px-2 py-1">{d["Valid Status"]}</td>
                        <td class="border px-2 py-1">{d["WAF"]}</td>
                      </tr>
                    {/each}
                  </tbody>
                </table>
              </div>
            </section>
          
          {:else if reportId === 'waf_not_akamai_domains'}
            <section>
              <h2 class="text-lg font-semibold mb-2">WAF Not Akamai Domains</h2>
              <div class="overflow-x-auto">
                <table class="table-auto w-full text-sm border">
                  <thead>
                    <tr>
                      <th class="border px-2 py-1">Domain</th>
                      <th class="border px-2 py-1">WAF</th>
                    </tr>
                  </thead>
                  <tbody>
                    {#each reportData.waf_not_akamai_domains as d}
                      <tr>
                        <td class="border px-2 py-1">{d.Domain}</td>
                        <td class="border px-2 py-1">{d.WAF}</td>
                      </tr>
                    {/each}
                  </tbody>
                </table>
              </div>
            </section>
    
          {:else if reportId === 'ssl_out'}
            <section>
              <h2 class="text-lg font-semibold mb-2">SSL Out</h2>
              <ul class="list-disc pl-6">
                {#each reportData.ssl_out as ssl}
                  <li>{ssl}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'inactive_subdomains'}
            <section>
              <h2 class="text-lg font-semibold mb-2">Inactive Subdomains</h2>
              <ul class="list-disc pl-6">
                {#each reportData.inactive_subdomains as subdomain}
                  <li>{subdomain}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'httpx_output_live_with_status_code'}
            <section>
              <h2 class="text-lg font-semibold mb-2">HTTPX Output Live with Status Code</h2>
              <ul class="list-disc pl-6">
                {#each reportData.httpx_output_live_with_status_code as output}
                  <li>{output}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'cdncheck_sanitize'}
            <section>
              <h2 class="text-lg font-semibold mb-2">CDN Check Sanitize</h2>
              <ul class="list-disc pl-6">
                {#each reportData.cdncheck_sanitize as cdn}
                  <li>{cdn}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'active_subdomains'}
            <section>
              <h2 class="text-lg font-semibold mb-2">Active Subdomains</h2>
              <ul class="list-disc pl-6">
                {#each reportData.active_subdomains as subdomain}
                  <li>{subdomain}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'misconfigured_cors'}
            <section>
              <h2 class="text-lg font-semibold mb-2">Misconfigured CORS</h2>
              <div class="overflow-x-auto">
                <table class="table-auto w-full text-sm border">
                  <thead>
                    <tr>
                      <th class="border px-2 py-1">Domain</th>
                      <th class="border px-2 py-1">Vulnerable Origin</th>
                    </tr>
                  </thead>
                  <tbody>
                    {#each reportData.misconfigured_cors as cors}
                      <tr>
                        <td class="border px-2 py-1">{cors.Domain}</td>
                        <td class="border px-2 py-1">{cors["Vulnerable Origin"]}</td>
                      </tr>
                    {/each}
                  </tbody>
                </table>
              </div>
            </section>
    
          {:else if reportId === 'ssl_final'}
            <section>
              <h2 class="text-lg font-semibold mb-2">SSL Final</h2>
              <ul class="list-disc pl-6">
                {#each reportData.ssl_final as ssl}
                  <li>{ssl}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'ssl_out_sanitize'}
            <section>
              <h2 class="text-lg font-semibold mb-2">SSL Out Sanitize</h2>
              <ul class="list-disc pl-6">
                {#each reportData.ssl_out_sanitize as ssl}
                  <li>{ssl}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'cdncheck_output'}
            <section>
              <h2 class="text-lg font-semibold mb-2">CDN Check Output</h2>
              <ul class="list-disc pl-6">
                {#each reportData.cdncheck_output as cdn}
                  <li>{cdn}</li>
                {/each}
              </ul>
            </section>
    
          {:else if reportId === 'outdated_tlsv_domains'}
            <section>
              <h2 class="text-lg font-semibold mb-2">Outdated TLSv Domains</h2>
              <div class="overflow-x-auto">
                <table class="table-auto w-full text-sm border">
                  <thead>
                    <tr>
                      <th class="border px-2 py-1">Domain</th>
                      <th class="border px-2 py-1">TLSv1.0</th>
                      <th class="border px-2 py-1">TLSv1.1</th>
                    </tr>
                  </thead>
                  <tbody>
                    {#each reportData.outdated_tlsv_domains as d}
                      <tr>
                        <td class="border px-2 py-1">{d.Domain}</td>
                        <td class="border px-2 py-1">{d["TLSv1.0"]}</td>
                        <td class="border px-2 py-1">{d["TLSv1.1"]}</td>
                      </tr>
                    {/each}
                  </tbody>
                </table>
              </div>
            </section>
    
          {:else if reportId === 'dnsx_ip_address'}
            <section>
              <h2 class="text-lg font-semibold mb-2">DNSX IP Addresses</h2>
              <ul class="list-disc pl-6">
                {#each reportData.dnsx_ip_address as ip}
                  <li>{ip}</li>
                {/each}
              </ul>
            </section>
    
          {/if}
          
        </div>
      </div>
    {/if}
    
  </div>
</div>