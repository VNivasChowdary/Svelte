<script lang="ts">
  import { push } from 'svelte-spa-router';
  import FileUpload from '../components/FileUpload.svelte';
  import TypeSelector from '../components/TypeSelector.svelte';
  import type { SelectionType } from '../types';
  
  let selectedType: SelectionType = 'domain';
  let domains: string[] = [];
  let isFormValid = false;
  let manualDomains = '';
  let showPreview = false;
  
  function handleTypeSelect(event: CustomEvent) {
    selectedType = event.detail.type;
    validateForm();
  }
  
  function handleFileProcessed(event: CustomEvent) {
    domains = event.detail.domains;
    manualDomains = '';
    showPreview = true;
    validateForm();
  }
  
  function handleManualDomainsInput(event: Event) {
    const input = event.target as HTMLTextAreaElement;
    manualDomains = input.value;
    
    if (manualDomains.trim()) {
      domains = manualDomains
        .split(/[\s,]+/)
        .map(item => item.trim())
        .filter(item => item.length > 0);
      showPreview = true;
    } else {
      domains = [];
      showPreview = false;
    }
    
    validateForm();
  }
  
  function validateForm() {
    isFormValid = domains.length > 0;
  }
  
  function submitForm() {
    if (!isFormValid) return;
    
    sessionStorage.setItem('reportRequest', JSON.stringify({
      type: selectedType,
      domain: domains
    }));
    
    push('/report/default');
  }

  function togglePreview() {
    showPreview = !showPreview;
  }
</script>

<!-- <div class="max-w-2xl mx-auto animate-slide-in">
  <h1 class="text-2xl font-semibold mb-4 text-neutral-800">Generate Report</h1>
  
  <div class="card space-y-6">
    <TypeSelector {selectedType} on:select={handleTypeSelect} />
    
    <div class="space-y-3">
      <h3 class="text-lg font-medium text-neutral-800">Enter Domains</h3>
      
      <div class="relative">
        <textarea 
          class="input w-full h-24 font-mono text-sm"
          placeholder="Enter domains separated by commas or new lines..."
          value={manualDomains}
          on:input={handleManualDomainsInput}
        ></textarea>
        {#if domains.length > 0}
          <button 
            class="absolute right-2 bottom-2 text-sm text-primary-500 hover:text-primary-600"
            on:click={togglePreview}
          >
            {showPreview ? 'Hide Preview' : 'Show Preview'}
          </button>
        {/if}
      </div>
      
      <div class="text-sm text-neutral-600">Or upload a text file:</div>
      <FileUpload on:fileProcessed={handleFileProcessed} />
    </div>
    
    {#if showPreview && domains.length > 0}
      <div class="animate-fade-in">
        <h3 class="text-sm font-medium text-neutral-800 mb-2">Preview ({domains.length} {domains.length === 1 ? 'domain' : 'domains'})</h3>
        <div class="bg-neutral-50 p-2 rounded-md border border-neutral-200 max-h-32 overflow-y-auto">
          <ul class="list-disc pl-4 space-y-0.5">
            {#each domains.slice(0, 5) as domain}
              <li class="text-sm text-neutral-700">{domain}</li>
            {/each}
            {#if domains.length > 5}
              <li class="text-sm text-neutral-500 italic">+ {domains.length - 5} more...</li>
            {/if}
          </ul>
        </div>
      </div>
    {/if}
    
    <div class="flex justify-end pt-2">
      <button 
        class="btn btn-primary"
        disabled={!isFormValid}
        class:opacity-50={!isFormValid}
        class:cursor-not-allowed={!isFormValid}
        on:click={submitForm}
      >
        Generate Report
      </button>
    </div>
  </div>
</div> -->