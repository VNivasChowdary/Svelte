/**
 * API service for handling all API requests
 */
const API_BASE_URL = "http://localhost:5000";

interface Report {
  id: string;
  name: string;
  description?: string;
}

export interface ReportRequest {
  reportId: string;
  // any other fields if needed
}

export interface ReportData {
  dns_records: any[];
  ip_address: string[];
  waf_not_akamai_domains: any[];
  ssl_out: string[];
  inactive_subdomains: string[];
  httpx_output_live_with_status_code: string[];
  cdncheck_sanitize: string[];
  domain_status: any[];
  active_subdomains: string[];
  misconfigured_cors: any[];
  ssl_final: string[];
  ssl_out_sanitize: string[];
  cdncheck_output: string[];
  outdated_tlsv_domains: any[];
  dnsx_ip_address: string[];
}

// Demo data for reports
const DEMO_REPORTS: Report[] = [
  {
    id: "dns_records",
    name: "DNS Records",
    description: "DNS entries including A, CNAME, and TXT records",
  },
  {
    id: "ip_address",
    name: "IP Addresses",
    description: "List of scanned IP addresses from sources",
  },
  {
    id: "waf",
    name: "WAF Domains",
    description: "Domains protected by Web Application Firewalls",
  },
  {
    id: "ssl",
    name: "SSL Information",
    description: "SSL versions and OpenSSL details",
  },
  {
    id: "subdomain_status",
    name: "Subdomain Status",
    description: "Active, inactive subdomains and their response status",
  },
  {
    id: "cdn",
    name: "CDN & Domain Info",
    description: "CDN providers and domain security details",
  },
  {
    id: "cors_tls",
    name: "CORS & TLS Issues",
    description: "Misconfigured CORS and outdated TLS protocols",
  },
];

// Demo report data
const DEMO_REPORT_DATA = {
  dns_records: {
    dns_records: [
      {
        Domain: "ada-ws22-test.highradius.com",
        "A Records": "96.17.150.161, 96.17.150.162",
        "CNAME Records": "prawsus.highradius.com.",
        "TXT Records": "",
      },
      {
        Domain: "ada-ws2g-test.highradius.com",
        "A Records": "96.17.150.162, 96.17.150.161",
        "CNAME Records": "prawsus-gold.highradius.com.",
        "TXT Records": "",
      },
    ],
  },
  ip_address: {
    ip_address: ["52.207.191.220", "52.58.170.126"],
    dnsx_ip_address: [
      "360sb.highradius.com [A] [52.207.191.220]",
      "accounts5.highradius.com [A] [52.58.170.126]",
    ],
  },
  waf: {
    waf_not_akamai_domains: [
      {
        Domain: "ada-ws22-test.highradius.com",
        WAF: "Kona SiteDefender",
      },
      {
        Domain: "ada-ws2g-test.highradius.com",
        WAF: "Kona SiteDefender",
      },
    ],
  },
  ssl: {
    ssl_out: ["Version: 2.1.4-6-ga1b0292-static", "OpenSSL 3.0.15 3 Sep 2024"],
    ssl_out_sanitize: [
      "Version: 2.1.4-6-ga1b0292-static",
      "OpenSSL 3.0.15 3 Sep 2024",
    ],
    ssl_final: [
      "ada-ws22-test.highradius.com disabled disabled disabled disabled enabled disabled",
      "ada-ws2g-test.highradius.com disabled disabled disabled disabled enabled disabled",
    ],
  },
  subdomain_status: {
    active_subdomains: [
      "ada-ws22-test.highradius.com",
      "ada-ws2g-test.highradius.com",
    ],
    inactive_subdomains: [
      "911-dev31.highradius.com",
      "911-dev31node1.highradius.com",
    ],
    httpx_output_live_with_status_code: [
      "https://ada-ws22-test.highradius.com [400]",
      "https://ada-ws2g-test.highradius.com [400]",
    ],
  },
  cdn: {
    cdncheck_sanitize: [
      "ada-ws22-test.highradius.com [akamai]",
      "ada-ws2g-test.highradius.com [akamai]",
    ],
    cdncheck_output: [
      "ada-ws22-test.highradius.com [waf] [akamai]",
      "ada-ws2g-test.highradius.com [waf] [akamai]",
    ],
    domain_status: [
      {
        Domain: "ada-ws22-test.highradius.com",
        "Status Code": "400",
        "IP Address": "['23.196.14.32', '23.196.14.42']",
        CDN: "[akamai]",
        SSLv2: "disabled",
        SSLv3: "disabled",
        TLSv1_0: "disabled",
        TLSv1_1: "disabled",
        TLSv1_2: "enabled",
        TLSv1_3: "disabled",
        "Crt Issue Date": "2024-09-17 00:00:00+00:00",
        "Crt Expiration Date": "2025-09-18 23:59:59+00:00",
        "Valid Status": "Valid",
        WAF: "Kona SiteDefender",
      },
      {
        Domain: "ada-ws2g-test.highradius.com",
        "Status Code": "400",
        "IP Address": "['23.212.0.203', '23.212.0.214']",
        CDN: "[akamai]",
        SSLv2: "disabled",
        SSLv3: "disabled",
        TLSv1_0: "disabled",
        TLSv1_1: "disabled",
        TLSv1_2: "enabled",
        TLSv1_3: "disabled",
        "Crt Issue Date": "2024-09-17 00:00:00+00:00",
        "Crt Expiration Date": "2025-09-18 23:59:59+00:00",
        "Valid Status": "Valid",
        WAF: "Kona SiteDefender",
      },
    ],
  },
  cors_tls: {
    misconfigured_cors: [
      {
        Domain: "events.highradius.com",
        "Vulnerable Origin": "https://fakehighradius.com",
      },
    ],
    outdated_tlsv_domains: [
      {
        Domain: "baml-akainternal.highradius.com",
        TLSv1_0: "disabled",
        TLSv1_1: "enabled",
      },
      {
        Domain: "cfotech-ap1.highradius.com",
        TLSv1_0: "enabled",
        TLSv1_1: "enabled",
      },
    ],
  },
};

/**
 * Fetches available reports from the API
 */
export async function getAvailableReports(): Promise<Report[]> {
  try {
    // For demo purposes, return updated mock reports
    const DEMO_REPORTS: Report[] = [
      {
        id: "dns_records",
        name: "DNS Records",
        description: "Details of A, CNAME, and TXT records",
      },
      {
        id: "ip_address",
        name: "IP Addresses",
        description: "List of discovered IP addresses",
      },
      {
        id: "waf_not_akamai_domains",
        name: "WAF Check",
        description: "Domains using non-Akamai WAFs",
      },
      {
        id: "ssl_out",
        name: "SSL Output",
        description: "Raw SSL version info",
      },
      {
        id: "ssl_final",
        name: "Final SSL Config",
        description: "Formatted SSL/TLS version info",
      },
      {
        id: "inactive_subdomains",
        name: "Inactive Subdomains",
        description: "Subdomains that appear to be inactive",
      },
      {
        id: "httpx_output_live_with_status_code",
        name: "Live Domains",
        description: "Domains with HTTP status from httpx",
      },
      {
        id: "cdncheck_sanitize",
        name: "CDN Check (Sanitized)",
        description: "CDN detection results (cleaned)",
      },
      {
        id: "domain_status",
        name: "Domain Status",
        description: "Detailed domain status including certs, TLS, WAF",
      },
      {
        id: "active_subdomains",
        name: "Active Subdomains",
        description: "Subdomains currently live",
      },
      {
        id: "misconfigured_cors",
        name: "Misconfigured CORS",
        description: "Domains vulnerable to CORS misconfig",
      },
      {
        id: "cdncheck_output",
        name: "CDN Check (Raw)",
        description: "Raw output from CDN check tool",
      },
      {
        id: "outdated_tlsv_domains",
        name: "Outdated TLS Versions",
        description: "Domains using older TLS versions",
      },
      {
        id: "dnsx_ip_address",
        name: "DNSx IP Mapping",
        description: "DNSx tool output of domains and IPs",
      },
    ];

    return DEMO_REPORTS;
  } catch (error) {
    if (error instanceof TypeError && error.message === "Failed to fetch") {
      throw new Error(
        "Unable to connect to the API server. Please ensure the server is running at " +
          API_BASE_URL
      );
    }
    console.error("Error fetching reports:", error);
    throw error;
  }
}

/**
 * Fetches report data based on domain and type
 */
export async function getReportData(): Promise<ReportData> {
  const response = await fetch(`${API_BASE_URL}/reports`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    throw new Error("Failed to fetch report data");
  }

  const data = await response.json();
  return data as ReportData;
}

/**
 * Converts report data to CSV format
 */
export function convertToCSV(data: any): string {
  if (!data) return "";

  let rows: any[] = [];
  let headers: string[] = [];

  if (data.dns_records) {
    headers = ["Domain", "A Records", "CNAME Records", "TXT Records"];
    rows = data.dns_records.map((d: any) => [
      d.Domain,
      d["A Records"],
      d["CNAME Records"],
      d["TXT Records"],
    ]);
  } else if (data.ip_address && Array.isArray(data.ip_address)) {
    headers = ["IP Address"];
    rows = data.ip_address.map((ip: string) => [ip]);
  } else if (data.waf_not_akamai_domains) {
    headers = ["Domain", "WAF"];
    rows = data.waf_not_akamai_domains.map((w: any) => [w.Domain, w.WAF]);
  } else if (data.ssl_out || data.ssl_final) {
    headers = ["SSL Info"];
    rows = [...(data.ssl_out || []), ...(data.ssl_final || [])].map(
      (entry: string) => [entry]
    );
  } else if (data.active_subdomains || data.inactive_subdomains) {
    headers = ["Status", "Subdomain"];
    rows = [
      ...(data.active_subdomains || []).map((d: string) => ["Active", d]),
      ...(data.inactive_subdomains || []).map((d: string) => ["Inactive", d]),
    ];
  } else if (data.domain_status) {
    headers = [
      "Domain",
      "Status Code",
      "IP Address",
      "CDN",
      "TLSv1.0",
      "TLSv1.1",
      "TLSv1.2",
      "TLSv1.3",
      "Certificate Issue Date",
      "Certificate Expiry Date",
      "Valid Status",
      "WAF",
    ];
    rows = data.domain_status.map((d: any) => [
      d.Domain,
      d["Status Code"],
      d["IP Address"],
      d.CDN,
      d.TLSv1_0,
      d.TLSv1_1,
      d.TLSv1_2,
      d.TLSv1_3,
      d["Crt Issue Date"],
      d["Crt Expiration Date"],
      d["Valid Status"],
      d.WAF,
    ]);
  } else if (data.misconfigured_cors) {
    headers = ["Domain", "Vulnerable Origin"];
    rows = data.misconfigured_cors.map((c: any) => [
      c.Domain,
      c["Vulnerable Origin"],
    ]);
  } else if (data.outdated_tlsv_domains) {
    headers = ["Domain", "TLSv1.0", "TLSv1.1"];
    rows = data.outdated_tlsv_domains.map((o: any) => [
      o.Domain,
      o.TLSv1_0,
      o.TLSv1_1,
    ]);
  } else if (data.dnsx_ip_address) {
    headers = ["DNSx Entry"];
    rows = data.dnsx_ip_address.map((entry: string) => [entry]);
  } else if (data.httpx_output_live_with_status_code) {
    headers = ["Live Domain [Status Code]"];
    rows = data.httpx_output_live_with_status_code.map((entry: string) => [
      entry,
    ]);
  } else if (data.cdncheck_output) {
    headers = ["CDN Check"];
    rows = data.cdncheck_output.map((entry: string) => [entry]);
  }

  if (!headers.length || !rows.length) return "No data available.";

  const csvContent = [
    headers.join(","),
    ...rows.map((row) => row.map((cell: any) => `"${cell}"`).join(",")),
  ].join("\n");

  return csvContent;
}

/**
 * Parses a text file and returns an array of domains
 */
export function parseTextFile(file: File): Promise<string[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (event) => {
      if (!event.target) {
        reject(new Error("File read error"));
        return;
      }

      const content = event.target.result as string;
      const domains = content
        .split(/[\s,]+/)
        .map((item) => item.trim())
        .filter((item) => item.length > 0);

      resolve(domains);
    };

    reader.onerror = () => {
      reject(new Error("Error reading file"));
    };

    reader.readAsText(file);
  });
}
