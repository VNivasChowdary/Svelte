// backend/server.js
const express = require("express");
const cors = require("cors");
const app = express();
const PORT = 5000;

app.use(cors());

const data = require("./data.json");

app.get("/reports", (req, res) => {
  res.json(data);
});

app.get("/getReport", (req, res) => {
  res.json({ message: "This is /getReport endpoint" });
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
